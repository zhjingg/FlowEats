import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'package:firebase_storage/firebase_storage.dart' as storage;
import 'package:cloud_firestore/cloud_firestore.dart';

class ProductManagement extends StatefulWidget {
  @override
  _ProductManagementState createState() => _ProductManagementState();
}

class _ProductManagementState extends State<ProductManagement> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController nameController = TextEditingController();
  final TextEditingController priceController = TextEditingController();
  XFile? _imageFile;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Product Management"),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (_imageFile != null)
                Image.file(
                  File(_imageFile!.path),
                  height: 200,
                ),
              ElevatedButton(
                onPressed: _pickImage,
                child: Text("Pick an Image"),
              ),
              TextFormField(
                controller: nameController,
                decoration: InputDecoration(labelText: "Product Name"),
                validator: (value) {
                  if (value!.isEmpty) {
                    return "Please enter a product name";
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: priceController,
                decoration: InputDecoration(labelText: "Price (\$)"),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value!.isEmpty) {
                    return "Please enter a price";
                  }
                  if (double.tryParse(value) == null) {
                    return "Invalid price format";
                  }
                  return null;
                },
              ),
              ElevatedButton(
                onPressed: _submitForm,
                child: Text("Submit"),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _pickImage() async {
    final picker = ImagePicker();
    final image = await picker.pickImage(source: ImageSource.gallery);
    setState(() {
      _imageFile = image;
    });
  }

  void _submitForm() async {
    if (_formKey.currentState!.validate()) {
      final productName = nameController.text;
      final productPrice = double.parse(priceController.text);

      if (_imageFile != null) {
        final File image = File(_imageFile!.path);

        final storage.Reference storageReference =
        storage.FirebaseStorage.instance.ref().child('product_images/$productName.jpg');

        final storage.UploadTask uploadTask = storageReference.putFile(image);

        storage.TaskSnapshot taskSnapshot = await uploadTask.whenComplete(() {
          storageReference.getDownloadURL().then((imageUrl) {
            final productData = {
              'name': productName,
              'price': productPrice,
              'image_url': imageUrl,
            };

            FirebaseFirestore.instance.collection('products').add(productData);

            // Clear the form fields and image after submission
            nameController.clear();
            priceController.clear();
            setState(() {
              _imageFile = null;
            });
          });
        });
      } else {
        // Handle the case where no image is selected
      }
    }
  }
}
