import 'package:flutter/material.dart';
import 'package:uber_app/authenthication/auth_screen.dart';
import 'package:uber_app/global/global.dart';

import '../authenthication/product_management.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Seller Home"),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              "Welcome, Seller!",
              style: TextStyle(fontSize: 24),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // Add functionality to manage seller orders
              },
              child: Text("Manage Orders"),
            ),
            const SizedBox(height: 10),
            ElevatedButton(
              onPressed: () {
                // Navigation to the product/menu management screen
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (context) => ProductManagement(),
                  ),
                );
              },
              child: Text("Manage Menu"),
            ),
            const SizedBox(height: 10),
            ElevatedButton(
              onPressed: () {
                // Add functionality to view earnings and statistics
              },
              child: Text("View Earnings"),
            ),
            const SizedBox(height: 10),
            ElevatedButton(
              onPressed: () {
                // Add functionality to sign out
                firebaseAuth.signOut();
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (context) => AuthScreen(),
                  ),
                );
              },
              child: Text("Sign Out"),
            ),
          ],
        ),
      ),
    );
  }
}
